import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRightIcon } from 'lucide-react';
export function Hero() {
  return <section id="home" className="relative min-h-screen flex items-center bg-gradient-to-br from-red-50 via-orange-50 to-yellow-50 overflow-hidden pt-20">
      {/* Animated Background Elements */}
      <motion.div className="absolute top-20 right-10 w-32 h-32 bg-red-200 rounded-full blur-3xl opacity-40" animate={{
      scale: [1, 1.2, 1],
      x: [0, 30, 0],
      y: [0, -20, 0]
    }} transition={{
      duration: 8,
      repeat: Infinity,
      ease: 'easeInOut'
    }} />
      <motion.div className="absolute bottom-20 left-10 w-40 h-40 bg-orange-200 rounded-full blur-3xl opacity-40" animate={{
      scale: [1, 1.3, 1],
      x: [0, -30, 0],
      y: [0, 20, 0]
    }} transition={{
      duration: 10,
      repeat: Infinity,
      ease: 'easeInOut'
    }} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 grid md:grid-cols-2 gap-12 items-center relative z-10">
        {/* Left Content */}
        <motion.div initial={{
        opacity: 0,
        x: -50
      }} animate={{
        opacity: 1,
        x: 0
      }} transition={{
        duration: 0.8
      }} className="space-y-6">
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 0.2
        }} className="inline-block bg-red-100 text-red-600 px-4 py-2 rounded-full text-sm font-semibold">
            🍕 Fresh & Hot Delivery
          </motion.div>

          <motion.h1 initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 0.3
        }} className="text-5xl sm:text-6xl lg:text-7xl font-bold text-gray-900 leading-tight">
            Delicious Pizza
            <span className="text-red-600"> Delivered</span> to Your Door
          </motion.h1>

          <motion.p initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 0.4
        }} className="text-lg text-gray-600 leading-relaxed">
            Handcrafted with love, baked to perfection. Experience the authentic
            taste of Italy in every bite.
          </motion.p>

          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 0.5
        }} className="flex flex-wrap gap-4">
            <motion.button className="bg-red-600 text-white px-8 py-4 rounded-full font-semibold text-lg shadow-xl flex items-center gap-2" whileHover={{
            scale: 1.05,
            boxShadow: '0 20px 40px rgba(220, 38, 38, 0.3)'
          }} whileTap={{
            scale: 0.95
          }}>
              Order Now
              <ArrowRightIcon className="w-5 h-5" />
            </motion.button>
            <motion.button className="bg-white text-gray-900 px-8 py-4 rounded-full font-semibold text-lg shadow-xl border-2 border-gray-200" whileHover={{
            scale: 1.05,
            borderColor: '#DC2626'
          }} whileTap={{
            scale: 0.95
          }}>
              View Menu
            </motion.button>
          </motion.div>
        </motion.div>

        {/* Right Content - Animated Pizza */}
        <motion.div initial={{
        opacity: 0,
        scale: 0.8
      }} animate={{
        opacity: 1,
        scale: 1
      }} transition={{
        duration: 0.8,
        delay: 0.3
      }} className="relative">
          <motion.div animate={{
          rotate: 360
        }} transition={{
          duration: 30,
          repeat: Infinity,
          ease: 'linear'
        }} className="relative">
            <img src="https://images.unsplash.com/photo-1513104890138-7c749659a591?w=800&h=800&fit=crop" alt="Delicious Pizza" className="w-full h-auto rounded-full shadow-2xl" />
          </motion.div>

          {/* Floating Ingredients */}
          <motion.div animate={{
          y: [0, -20, 0]
        }} transition={{
          duration: 3,
          repeat: Infinity,
          ease: 'easeInOut'
        }} className="absolute -top-10 -right-10 bg-white p-4 rounded-2xl shadow-xl">
            <span className="text-4xl">🍅</span>
          </motion.div>
          <motion.div animate={{
          y: [0, -15, 0]
        }} transition={{
          duration: 4,
          repeat: Infinity,
          ease: 'easeInOut',
          delay: 0.5
        }} className="absolute -bottom-5 -left-5 bg-white p-4 rounded-2xl shadow-xl">
            <span className="text-4xl">🧀</span>
          </motion.div>
          <motion.div animate={{
          y: [0, -25, 0]
        }} transition={{
          duration: 3.5,
          repeat: Infinity,
          ease: 'easeInOut',
          delay: 1
        }} className="absolute top-1/2 -left-10 bg-white p-4 rounded-2xl shadow-xl">
            <span className="text-4xl">🌿</span>
          </motion.div>
        </motion.div>
      </div>
    </section>;
}