import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MenuIcon, XIcon, PizzaIcon } from 'lucide-react';
export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  const navLinks = [{
    name: 'Home',
    href: '#home'
  }, {
    name: 'About',
    href: '#about'
  }, {
    name: 'Menu',
    href: '#menu'
  }, {
    name: 'Offers',
    href: '#offers'
  }, {
    name: 'Reviews',
    href: '#reviews'
  }, {
    name: 'Contact',
    href: '#contact'
  }];
  return <motion.nav initial={{
    y: -100
  }} animate={{
    y: 0
  }} className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-lg' : 'bg-white/95 backdrop-blur-sm'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <motion.a href="#home" className="flex items-center gap-2 text-2xl font-bold text-red-600" whileHover={{
          scale: 1.05
        }} whileTap={{
          scale: 0.95
        }}>
            <PizzaIcon className="w-8 h-8" />
            <span>PizzaHub</span>
          </motion.a>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link, index) => <motion.a key={link.name} href={link.href} className="text-gray-700 hover:text-red-600 font-medium transition-colors" initial={{
            opacity: 0,
            y: -20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: index * 0.1
          }} whileHover={{
            y: -2
          }}>
                {link.name}
              </motion.a>)}
            <motion.button className="bg-red-600 text-white px-6 py-2.5 rounded-full font-semibold shadow-lg" whileHover={{
            scale: 1.05,
            boxShadow: '0 10px 25px rgba(220, 38, 38, 0.3)'
          }} whileTap={{
            scale: 0.95
          }}>
              Order Now
            </motion.button>
          </div>

          {/* Mobile Menu Button */}
          <motion.button className="md:hidden text-gray-700 p-2" onClick={() => setIsOpen(!isOpen)} whileTap={{
          scale: 0.9
        }}>
            {isOpen ? <XIcon className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
          </motion.button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && <motion.div initial={{
        opacity: 0,
        height: 0
      }} animate={{
        opacity: 1,
        height: 'auto'
      }} exit={{
        opacity: 0,
        height: 0
      }} className="md:hidden bg-white border-t border-gray-200 overflow-hidden">
            <div className="px-4 py-6 space-y-4">
              {navLinks.map((link, index) => <motion.a key={link.name} href={link.href} className="block text-gray-700 hover:text-red-600 font-medium py-2" initial={{
            opacity: 0,
            x: -20
          }} animate={{
            opacity: 1,
            x: 0
          }} transition={{
            delay: index * 0.1
          }} onClick={() => setIsOpen(false)}>
                  {link.name}
                </motion.a>)}
              <motion.button className="w-full bg-red-600 text-white px-6 py-3 rounded-full font-semibold" initial={{
            opacity: 0,
            x: -20
          }} animate={{
            opacity: 1,
            x: 0
          }} transition={{
            delay: navLinks.length * 0.1
          }} whileTap={{
            scale: 0.95
          }}>
                Order Now
              </motion.button>
            </div>
          </motion.div>}
      </AnimatePresence>
    </motion.nav>;
}