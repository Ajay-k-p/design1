import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'framer-motion';
import { StarIcon, ChevronLeftIcon, ChevronRightIcon } from 'lucide-react';
export function Reviews() {
  const ref = useRef(null);
  const isInView = useInView(ref, {
    once: true,
    margin: '-100px'
  });
  const [currentIndex, setCurrentIndex] = useState(0);
  const reviews = [{
    name: 'Sarah Johnson',
    rating: 5,
    comment: 'Best pizza in town! The crust is perfect and the toppings are always fresh. Delivery is super fast too!',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop'
  }, {
    name: 'Michael Chen',
    rating: 5,
    comment: 'Amazing flavors and great value for money. The BBQ Chicken pizza is my absolute favorite!',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop'
  }, {
    name: 'Emily Rodriguez',
    rating: 5,
    comment: 'I order from PizzaHub at least twice a week. Never disappoints! The family deal is perfect for our movie nights.',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop'
  }, {
    name: 'David Thompson',
    rating: 5,
    comment: 'Authentic Italian taste! You can tell they use quality ingredients. Highly recommended!',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop'
  }];
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % reviews.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [reviews.length]);
  const handlePrev = () => {
    setCurrentIndex(prev => (prev - 1 + reviews.length) % reviews.length);
  };
  const handleNext = () => {
    setCurrentIndex(prev => (prev + 1) % reviews.length);
  };
  return <section id="reviews" ref={ref} className="py-20 bg-gradient-to-br from-red-50 to-orange-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div initial={{
        opacity: 0,
        y: 30
      }} animate={isInView ? {
        opacity: 1,
        y: 0
      } : {}} transition={{
        duration: 0.6
      }} className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            Customer <span className="text-red-600">Reviews</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Don't just take our word for it. Here's what our happy customers
            have to say!
          </p>
        </motion.div>

        <div className="relative max-w-4xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div key={currentIndex} initial={{
            opacity: 0,
            x: 100
          }} animate={{
            opacity: 1,
            x: 0
          }} exit={{
            opacity: 0,
            x: -100
          }} transition={{
            duration: 0.5
          }} className="bg-white rounded-3xl p-8 md:p-12 shadow-2xl">
              <div className="flex flex-col md:flex-row items-center gap-8">
                <motion.img src={reviews[currentIndex].avatar} alt={reviews[currentIndex].name} className="w-24 h-24 rounded-full object-cover shadow-lg" whileHover={{
                scale: 1.1
              }} />
                <div className="flex-1 text-center md:text-left">
                  <div className="flex justify-center md:justify-start gap-1 mb-3">
                    {[...Array(reviews[currentIndex].rating)].map((_, i) => <StarIcon key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />)}
                  </div>
                  <p className="text-xl text-gray-700 mb-4 italic">
                    "{reviews[currentIndex].comment}"
                  </p>
                  <p className="text-lg font-bold text-gray-900">
                    {reviews[currentIndex].name}
                  </p>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation Buttons */}
          <div className="flex justify-center gap-4 mt-8">
            <motion.button onClick={handlePrev} className="bg-white p-3 rounded-full shadow-lg text-gray-700" whileHover={{
            scale: 1.1,
            backgroundColor: '#DC2626',
            color: '#fff'
          }} whileTap={{
            scale: 0.9
          }}>
              <ChevronLeftIcon className="w-6 h-6" />
            </motion.button>
            <motion.button onClick={handleNext} className="bg-white p-3 rounded-full shadow-lg text-gray-700" whileHover={{
            scale: 1.1,
            backgroundColor: '#DC2626',
            color: '#fff'
          }} whileTap={{
            scale: 0.9
          }}>
              <ChevronRightIcon className="w-6 h-6" />
            </motion.button>
          </div>

          {/* Dots Indicator */}
          <div className="flex justify-center gap-2 mt-6">
            {reviews.map((_, index) => <motion.button key={index} onClick={() => setCurrentIndex(index)} className={`h-2 rounded-full transition-all ${index === currentIndex ? 'w-8 bg-red-600' : 'w-2 bg-gray-300'}`} whileHover={{
            scale: 1.2
          }} />)}
          </div>
        </div>
      </div>
    </section>;
}