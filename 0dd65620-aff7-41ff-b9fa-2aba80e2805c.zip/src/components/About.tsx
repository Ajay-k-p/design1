import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { ChefHatIcon, HeartIcon, ClockIcon } from 'lucide-react';
export function About() {
  const ref = useRef(null);
  const isInView = useInView(ref, {
    once: true,
    margin: '-100px'
  });
  const features = [{
    icon: ChefHatIcon,
    title: 'Expert Chefs',
    description: 'Our master chefs bring authentic Italian recipes to life with passion and precision.'
  }, {
    icon: HeartIcon,
    title: 'Fresh Ingredients',
    description: 'We source the finest local and imported ingredients for unmatched quality.'
  }, {
    icon: ClockIcon,
    title: 'Fast Delivery',
    description: 'Hot and fresh pizza delivered to your door in 30 minutes or less.'
  }];
  return <section id="about" ref={ref} className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div initial={{
        opacity: 0,
        y: 30
      }} animate={isInView ? {
        opacity: 1,
        y: 0
      } : {}} transition={{
        duration: 0.6
      }} className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            About <span className="text-red-600">PizzaHub</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Since 2010, we've been serving the most delicious, authentic pizzas
            crafted with love and the finest ingredients. Every pizza tells a
            story of tradition, quality, and passion.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => <motion.div key={feature.title} initial={{
          opacity: 0,
          y: 30
        }} animate={isInView ? {
          opacity: 1,
          y: 0
        } : {}} transition={{
          duration: 0.6,
          delay: index * 0.2
        }} className="bg-gradient-to-br from-red-50 to-orange-50 p-8 rounded-2xl text-center">
              <motion.div whileHover={{
            scale: 1.1,
            rotate: 5
          }} className="inline-block bg-red-600 text-white p-4 rounded-2xl mb-4">
                <feature.icon className="w-8 h-8" />
              </motion.div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>)}
        </div>
      </div>
    </section>;
}