import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { MapPinIcon, PhoneIcon, MailIcon, ClockIcon } from 'lucide-react';
export function Contact() {
  const ref = useRef(null);
  const isInView = useInView(ref, {
    once: true,
    margin: '-100px'
  });
  const contactInfo = [{
    icon: MapPinIcon,
    title: 'Location',
    info: '123 Pizza Street, Food City, FC 12345'
  }, {
    icon: PhoneIcon,
    title: 'Phone',
    info: '+1 (555) 123-4567'
  }, {
    icon: MailIcon,
    title: 'Email',
    info: 'hello@pizzahub.com'
  }, {
    icon: ClockIcon,
    title: 'Hours',
    info: 'Mon-Sun: 11:00 AM - 11:00 PM'
  }];
  return <section id="contact" ref={ref} className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div initial={{
        opacity: 0,
        y: 30
      }} animate={isInView ? {
        opacity: 1,
        y: 0
      } : {}} transition={{
        duration: 0.6
      }} className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            Contact <span className="text-red-600">Us</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Have questions? We'd love to hear from you. Get in touch with us!
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Contact Info */}
          <motion.div initial={{
          opacity: 0,
          x: -50
        }} animate={isInView ? {
          opacity: 1,
          x: 0
        } : {}} transition={{
          duration: 0.6
        }} className="space-y-6">
            {contactInfo.map((item, index) => <motion.div key={item.title} initial={{
            opacity: 0,
            x: -30
          }} animate={isInView ? {
            opacity: 1,
            x: 0
          } : {}} transition={{
            duration: 0.6,
            delay: index * 0.1
          }} whileHover={{
            x: 10
          }} className="flex items-start gap-4 bg-gradient-to-br from-red-50 to-orange-50 p-6 rounded-2xl">
                <div className="bg-red-600 text-white p-3 rounded-xl">
                  <item.icon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-1">
                    {item.title}
                  </h3>
                  <p className="text-gray-600">{item.info}</p>
                </div>
              </motion.div>)}
          </motion.div>

          {/* Map Placeholder */}
          <motion.div initial={{
          opacity: 0,
          x: 50
        }} animate={isInView ? {
          opacity: 1,
          x: 0
        } : {}} transition={{
          duration: 0.6
        }} className="bg-gradient-to-br from-red-100 to-orange-100 rounded-2xl overflow-hidden shadow-xl h-96 flex items-center justify-center">
            <div className="text-center">
              <MapPinIcon className="w-16 h-16 text-red-600 mx-auto mb-4" />
              <p className="text-gray-700 font-semibold text-lg">
                Interactive Map
              </p>
              <p className="text-gray-600 text-sm mt-2">
                Map integration placeholder
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>;
}