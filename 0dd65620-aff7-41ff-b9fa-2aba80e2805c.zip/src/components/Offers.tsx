import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { SparklesIcon, PercentIcon, GiftIcon } from 'lucide-react';
export function Offers() {
  const ref = useRef(null);
  const isInView = useInView(ref, {
    once: true,
    margin: '-100px'
  });
  const offers = [{
    icon: PercentIcon,
    title: '50% Off',
    subtitle: 'First Order',
    description: 'Get 50% off on your first order. Use code: FIRST50',
    color: 'from-red-500 to-orange-500'
  }, {
    icon: GiftIcon,
    title: 'Buy 2 Get 1',
    subtitle: 'Free Pizza',
    description: 'Order any 2 large pizzas and get 1 medium free!',
    color: 'from-orange-500 to-yellow-500'
  }, {
    icon: SparklesIcon,
    title: 'Family Deal',
    subtitle: '$39.99',
    description: '3 large pizzas + 2 sides + 1.5L drink',
    color: 'from-red-600 to-pink-500'
  }];
  return <section id="offers" ref={ref} className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div initial={{
        opacity: 0,
        y: 30
      }} animate={isInView ? {
        opacity: 1,
        y: 0
      } : {}} transition={{
        duration: 0.6
      }} className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            Special <span className="text-red-600">Offers</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Don't miss out on our amazing deals and limited-time offers!
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {offers.map((offer, index) => <motion.div key={offer.title} initial={{
          opacity: 0,
          scale: 0.9
        }} animate={isInView ? {
          opacity: 1,
          scale: 1
        } : {}} transition={{
          duration: 0.6,
          delay: index * 0.2
        }} whileHover={{
          scale: 1.05,
          rotate: 2
        }} className={`relative bg-gradient-to-br ${offer.color} p-8 rounded-3xl text-white overflow-hidden`}>
              {/* Animated Badge */}
              <motion.div animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 5, -5, 0]
          }} transition={{
            duration: 3,
            repeat: Infinity,
            ease: 'easeInOut'
          }} className="absolute -top-10 -right-10 w-32 h-32 bg-white/20 rounded-full blur-2xl" />

              <motion.div whileHover={{
            rotate: 360
          }} transition={{
            duration: 0.6
          }} className="inline-block bg-white/20 p-4 rounded-2xl mb-4">
                <offer.icon className="w-8 h-8" />
              </motion.div>

              <h3 className="text-3xl font-bold mb-1">{offer.title}</h3>
              <p className="text-xl font-semibold mb-4 opacity-90">
                {offer.subtitle}
              </p>
              <p className="text-white/90 mb-6">{offer.description}</p>

              <motion.button className="bg-white text-gray-900 px-6 py-3 rounded-full font-semibold" whileHover={{
            scale: 1.1,
            boxShadow: '0 10px 25px rgba(0, 0, 0, 0.2)'
          }} whileTap={{
            scale: 0.95
          }}>
                Claim Offer
              </motion.button>
            </motion.div>)}
        </div>
      </div>
    </section>;
}