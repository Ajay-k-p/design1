import React from 'react';
import { motion } from 'framer-motion';
import { PizzaIcon, FacebookIcon, InstagramIcon, TwitterIcon, YoutubeIcon } from 'lucide-react';
export function Footer() {
  const socialLinks = [{
    icon: FacebookIcon,
    href: '#',
    label: 'Facebook'
  }, {
    icon: InstagramIcon,
    href: '#',
    label: 'Instagram'
  }, {
    icon: TwitterIcon,
    href: '#',
    label: 'Twitter'
  }, {
    icon: YoutubeIcon,
    href: '#',
    label: 'YouTube'
  }];
  return <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 text-2xl font-bold text-red-500 mb-4">
              <PizzaIcon className="w-8 h-8" />
              <span>PizzaHub</span>
            </div>
            <p className="text-gray-400">
              Delivering happiness, one slice at a time. Fresh, hot, and
              delicious pizza made with love.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {['Home', 'About', 'Menu', 'Offers'].map(link => <li key={link}>
                  <motion.a href={`#${link.toLowerCase()}`} className="text-gray-400 hover:text-red-500 transition-colors" whileHover={{
                x: 5
              }}>
                    {link}
                  </motion.a>
                </li>)}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-bold mb-4">Contact</h3>
            <ul className="space-y-2 text-gray-400">
              <li>123 Pizza Street</li>
              <li>Food City, FC 12345</li>
              <li>+1 (555) 123-4567</li>
              <li>hello@pizzahub.com</li>
            </ul>
          </div>

          {/* Social Media */}
          <div>
            <h3 className="text-lg font-bold mb-4">Follow Us</h3>
            <div className="flex gap-4">
              {socialLinks.map(social => <motion.a key={social.label} href={social.href} aria-label={social.label} className="bg-gray-800 p-3 rounded-full text-gray-400 hover:bg-red-600 hover:text-white transition-colors" whileHover={{
              scale: 1.1,
              y: -5
            }} whileTap={{
              scale: 0.9
            }}>
                  <social.icon className="w-5 h-5" />
                </motion.a>)}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
          <p>&copy; 2024 PizzaHub. All rights reserved. Made with ❤️ and 🍕</p>
        </div>
      </div>
    </footer>;
}