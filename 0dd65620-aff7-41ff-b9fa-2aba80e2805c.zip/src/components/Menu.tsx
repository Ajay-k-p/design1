import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { PlusIcon } from 'lucide-react';
export function Menu() {
  const ref = useRef(null);
  const isInView = useInView(ref, {
    once: true,
    margin: '-100px'
  });
  const pizzas = [{
    name: 'Margherita',
    description: 'Classic tomato sauce, fresh mozzarella, basil',
    price: '$12.99',
    image: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=400&h=400&fit=crop'
  }, {
    name: 'Pepperoni',
    description: 'Spicy pepperoni, mozzarella, tomato sauce',
    price: '$14.99',
    image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=400&h=400&fit=crop'
  }, {
    name: 'Veggie Supreme',
    description: 'Bell peppers, mushrooms, olives, onions',
    price: '$13.99',
    image: 'https://images.unsplash.com/photo-1571997478779-2adcbbe9ab2f?w=400&h=400&fit=crop'
  }, {
    name: 'BBQ Chicken',
    description: 'Grilled chicken, BBQ sauce, red onions',
    price: '$15.99',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=400&fit=crop'
  }, {
    name: 'Hawaiian',
    description: 'Ham, pineapple, mozzarella cheese',
    price: '$14.99',
    image: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=400&h=400&fit=crop'
  }, {
    name: 'Meat Lovers',
    description: 'Pepperoni, sausage, bacon, ham',
    price: '$16.99',
    image: 'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?w=400&h=400&fit=crop'
  }];
  return <section id="menu" ref={ref} className="py-20 bg-gradient-to-br from-orange-50 to-red-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div initial={{
        opacity: 0,
        y: 30
      }} animate={isInView ? {
        opacity: 1,
        y: 0
      } : {}} transition={{
        duration: 0.6
      }} className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            Our <span className="text-red-600">Menu</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Explore our delicious selection of handcrafted pizzas, made fresh
            daily with premium ingredients.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {pizzas.map((pizza, index) => <motion.div key={pizza.name} initial={{
          opacity: 0,
          y: 50
        }} animate={isInView ? {
          opacity: 1,
          y: 0
        } : {}} transition={{
          duration: 0.6,
          delay: index * 0.1
        }} whileHover={{
          y: -10
        }} className="bg-white rounded-2xl overflow-hidden shadow-xl">
              <div className="relative overflow-hidden">
                <motion.img src={pizza.image} alt={pizza.name} className="w-full h-64 object-cover" whileHover={{
              scale: 1.1
            }} transition={{
              duration: 0.4
            }} />
                <div className="absolute top-4 right-4 bg-red-600 text-white px-3 py-1 rounded-full font-bold text-sm">
                  {pizza.price}
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">
                  {pizza.name}
                </h3>
                <p className="text-gray-600 mb-4">{pizza.description}</p>
                <motion.button className="w-full bg-red-600 text-white py-3 rounded-full font-semibold flex items-center justify-center gap-2" whileHover={{
              scale: 1.05,
              boxShadow: '0 10px 25px rgba(220, 38, 38, 0.3)'
            }} whileTap={{
              scale: 0.95
            }}>
                  <PlusIcon className="w-5 h-5" />
                  Add to Cart
                </motion.button>
              </div>
            </motion.div>)}
        </div>
      </div>
    </section>;
}