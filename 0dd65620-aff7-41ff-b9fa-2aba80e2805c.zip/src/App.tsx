import React from 'react';
import { PizzaShop } from './pages/PizzaShop';
export function App() {
  return <PizzaShop />;
}