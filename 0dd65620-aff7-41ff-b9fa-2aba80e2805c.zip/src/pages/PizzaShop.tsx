import React from 'react';
import { Navbar } from '../components/Navbar';
import { Hero } from '../components/Hero';
import { About } from '../components/About';
import { Menu } from '../components/Menu';
import { Offers } from '../components/Offers';
import { Reviews } from '../components/Reviews';
import { Contact } from '../components/Contact';
import { Footer } from '../components/Footer';
export function PizzaShop() {
  return <div className="w-full min-h-screen">
      <Navbar />
      <Hero />
      <About />
      <Menu />
      <Offers />
      <Reviews />
      <Contact />
      <Footer />
    </div>;
}